import React from "react";
// import Banner from "../components/Banner";
import Faq from "../components/Faq";
import Footer from "../components/Footer";
import Header from "../components/Header";
import Navbar from "../components/Navbar";
import Roadmap from "../components/Roadmap";
import Slider from "../components/Slider";

export default function Page() {
  return (
    <>
      {/* <Banner /> */}
      <Header />
    </>
  );
}
